
public class Rectangle implements FigureGeometry {

	public Rectangle(int i, int j) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public float perimeter() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float area() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setScale(int scale) {
		// TODO Auto-generated method stub

	}

	@Override
	public float weight() {
		// TODO Auto-generated method stub
		return 0;
	}

}
