package cs187.part1;

public class IncDate extends Date
{
  public IncDate(int newMonth, int newDay, int newYear)
  {
    super(newMonth, newDay, newYear);
  }

  public void increment()
  // Increments this IncDate to represent the next day.
  // For example if this = 6/30/2005 then this becomes 7/1/2005.
  {
    // increment algorithm goes here
  }
}
